default_app_config = 'wagtail.users.apps.WagtailUsersAppConfig'
