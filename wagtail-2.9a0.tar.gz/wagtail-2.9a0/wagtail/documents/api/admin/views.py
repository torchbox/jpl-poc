from ..v2.views import DocumentsAPIViewSet


class DocumentsAdminAPIViewSet(DocumentsAPIViewSet):
    pass
