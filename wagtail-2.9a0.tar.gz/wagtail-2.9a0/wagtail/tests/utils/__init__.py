from .page_tests import *  # NOQA
from .wagtail_tests import *  # NOQA
