default_app_config = 'wagtail.embeds.apps.WagtailEmbedsAppConfig'
