
class InvalidFilterSpecError(ValueError):
    pass
