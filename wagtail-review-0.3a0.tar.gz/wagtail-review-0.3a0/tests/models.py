from wagtail.core.models import Page


class SimplePage(Page):
    pass
